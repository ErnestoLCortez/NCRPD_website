INSERT INTO c9.wp_term_relationships (object_id, term_taxonomy_id, term_order) VALUES (1, 1, 0);
INSERT INTO c9.wp_term_relationships (object_id, term_taxonomy_id, term_order) VALUES (51, 6, 0);
INSERT INTO c9.wp_term_relationships (object_id, term_taxonomy_id, term_order) VALUES (52, 6, 0);
INSERT INTO c9.wp_term_relationships (object_id, term_taxonomy_id, term_order) VALUES (53, 6, 0);
INSERT INTO c9.wp_term_relationships (object_id, term_taxonomy_id, term_order) VALUES (54, 6, 0);
INSERT INTO c9.wp_term_relationships (object_id, term_taxonomy_id, term_order) VALUES (55, 6, 0);
INSERT INTO c9.wp_term_relationships (object_id, term_taxonomy_id, term_order) VALUES (56, 6, 0);
INSERT INTO c9.wp_term_relationships (object_id, term_taxonomy_id, term_order) VALUES (73, 1, 0);