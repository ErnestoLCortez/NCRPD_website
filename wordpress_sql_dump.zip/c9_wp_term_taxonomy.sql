INSERT INTO c9.wp_term_taxonomy (term_id, taxonomy, description, parent, count) VALUES (1, 'category', '', 0, 2);
INSERT INTO c9.wp_term_taxonomy (term_id, taxonomy, description, parent, count) VALUES (2, 'product_type', '', 0, 0);
INSERT INTO c9.wp_term_taxonomy (term_id, taxonomy, description, parent, count) VALUES (3, 'product_type', '', 0, 0);
INSERT INTO c9.wp_term_taxonomy (term_id, taxonomy, description, parent, count) VALUES (4, 'product_type', '', 0, 0);
INSERT INTO c9.wp_term_taxonomy (term_id, taxonomy, description, parent, count) VALUES (5, 'product_type', '', 0, 0);
INSERT INTO c9.wp_term_taxonomy (term_id, taxonomy, description, parent, count) VALUES (6, 'nav_menu', '', 0, 6);