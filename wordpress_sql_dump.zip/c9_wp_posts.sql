INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-20 19:35:09', '2017-03-20 19:35:09', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2017-03-20 19:35:09', '2017-03-20 19:35:09', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?p=1', 0, 'post', '', 1);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-20 22:20:03', '2017-03-20 22:20:03', '', 'News', '', 'publish', 'closed', 'closed', '', 'news', '', '', '2017-03-20 22:20:03', '2017-03-20 22:20:03', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?page_id=17', 0, 'page', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-20 22:20:03', '2017-03-20 22:20:03', '<h3>Welcome to the North County Recreation and Park District</h3>
NCRPD is a Local Government Agency (Special District) providing Recreation and Parks services to the North Monterey County area including the communities of Castroville, Moss Landing, Oak Hills and parts of Elkhorn and Prunedale, along with the surrounding rural community. NCRPD opperates the North County Recreation Center, Cato-Phillips Park, Crane Street Park, Japanese School Park, Rancho Moro Cojo Park and the Moro Cojo Nature Trails.
<h4>Vision</h4>
We create community through people, parks and programs.
<h4>Mission</h4>
Strengthen community image and sense of place
Support economic development
Strengthen safety and security
Promote health and wellness
Foster human development
Increase cultural unity
Protect environmental resources
Provide recreational experiences
Facilitate community problem solving
<h4>Youth</h4>
NCRPD hosts drop in recreational services for youth at the North County Rec Center Monday through Friday after school and beginning at 1pm during the summer and all school breaks. Activities include rock climbing, homework help, floor hockey, games, tournaments, crafts and cooking classes. Kids have access to the gym and any activities we offer at no charge. NCRPD is also the host site for a youth nutrition program that serves a full lunch Monday through Friday during the summer months and snack in the afternoon.
<h4>Seniors</h4>
NCRPD invites seniors all year long to enjoy cards, quilting, gym bowling, crafts, board games, bingo and a place to meet up with other seniors. Seniors also plan field trips to various local attractions like, the Monterey Bay Aquarium, Monterey County Fair, casino trips, shopping trips and more. The Castroville Senior Center also provides a HOT MEAL each weekday for a minimal donation. Guests are always welcome to join our seniors.
<h4>Adults</h4>
NCRPD offers sport leagues, recreational activities and classes for adults. The North County Recreation Center is also the local distribution site for the Monterey County Food Bank (call for schedule).

<em>Visit our Annual Events page for more information on Castroville''s Party in the Plaza: Joe Micheli Sr. Memorial Community Parade and Car Show</em>
<h4>Board Meetings and Board Agenda</h4>
The Board of Directors meet regularly on the second Wednesday of each month. Meeting time is 5:30pm. Meeting place is the North County Recreation Center-Meeting Room at 11261 Crane Street, Castroville, CA 95012. Agenda''s are prepared the Friday prior to the meeting. If you would like a topic to be placed on the agenda please call (831 633-3084) or visit the District office before that Friday.
<h3 style="text-align: center;">BOARD OF DIRECTOR’S MEETING</h3>
<img class="size-medium wp-image-44 aligncenter" src="https://ncrpd-website-ernestolcortez.c9users.io/wp-content/uploads/2017/03/dirMeetingAgenda-232x300.jpg" alt="" width="232" height="300" />', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-05-07 02:40:54', '2017-05-07 02:40:54', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?page_id=18', 0, 'page', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-20 22:20:03', '2017-03-20 22:20:03', '', 'News', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2017-03-20 22:20:03', '2017-03-20 22:20:03', '', 17, 'https://ncrpd-website-ernestolcortez.c9users.io/17-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-20 22:20:03', '2017-03-20 22:20:03', '', 'Home', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-03-20 22:20:03', '2017-03-20 22:20:03', '', 18, 'https://ncrpd-website-ernestolcortez.c9users.io/18-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-20 22:20:46', '2017-03-20 22:20:46', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2017-03-20 22:21:15', '2017-03-20 22:21:15', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/wp-content/uploads/2017/03/logo.gif', 0, 'attachment', 'image/gif', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-20 22:21:33', '2017-03-20 22:21:33', 'https://ncrpd-website-ernestolcortez.c9users.io/wp-content/uploads/2017/03/cropped-logo.gif', 'cropped-logo.gif', '', 'inherit', 'open', 'closed', '', 'cropped-logo-gif', '', '', '2017-03-20 22:21:33', '2017-03-20 22:21:33', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/wp-content/uploads/2017/03/cropped-logo.gif', 0, 'attachment', 'image/gif', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-24 00:05:36', '2017-03-24 00:05:36', '<label> Your Name (required)
    [text* your-name] </label>

<label> Your Email (required)
    [email* your-email] </label>

<label> Subject
    [text your-subject] </label>

<label> Your Message
    [textarea your-message] </label>

[submit "Send"]
North County Recreate and Park District "[your-subject]"
[your-name] <wordpress@ncrpd-website-ernestolcortez.c9users.io>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on North County Recreate and Park District (https://ncrpd-website-ernestolcortez.c9users.io)
ecortez@csumb.edu
Reply-To: [your-email]

0
0

North County Recreate and Park District "[your-subject]"
North County Recreate and Park District <wordpress@ncrpd-website-ernestolcortez.c9users.io>
Message Body:
[your-message]

-- 
This e-mail was sent from a contact form on North County Recreate and Park District (https://ncrpd-website-ernestolcortez.c9users.io)
[your-email]
Reply-To: ecortez@csumb.edu

0
0
Thank you for your message. It has been sent.
There was an error trying to send your message. Please try again later.
One or more fields have an error. Please check and try again.
There was an error trying to send your message. Please try again later.
You must accept the terms and conditions before sending your message.
The field is required.
The field is too long.
The field is too short.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2017-03-24 00:05:36', '2017-03-24 00:05:36', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?post_type=wpcf7_contact_form&p=27', 0, 'wpcf7_contact_form', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-27 06:17:02', '2017-03-27 06:17:02', 'NCRPD is a recreation and Parks district that serves the North Monterey County area including the communities of Castroville, Moss Landing, Oak Hills and parts of Elkhorn and Prunedale, along with the surrounding rural community. NCRPD opperates the North County Recreation Center, Cato-Phillips Park, Crane Street Park, Japanese School Park and the Rancho Moro Cojo Park.', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2017-03-28 08:14:19', '2017-03-28 08:14:19', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?page_id=34', 0, 'page', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-27 06:15:28', '2017-03-27 06:15:28', 'NCRPD is a recreation and Parks district that serves the North Monterey County area including the communities of Castroville, Moss Landing, Oak Hills and parts of Elkhorn and Prunedale, along with the surrounding rural community. NCRPD opperates the North County Recreation Center, Cato-Phillips Park, Crane Street Park, Japanese School Park and the Rancho Moro Cojo Park.', 'About', '', 'inherit', 'closed', 'closed', '', '34-revision-v1', '', '', '2017-03-27 06:15:28', '2017-03-27 06:15:28', '', 34, 'https://ncrpd-website-ernestolcortez.c9users.io/34-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 03:57:58', '2017-03-28 03:57:58', '<h3>Our Board Of Directors:</h3>
<ul>
 	<li>Grant Leonard- Chair  current term ends 11/30/2018</li>
 	<li>Kristen Henderson- Vice Chair current term ends 11/30/2018</li>
 	<li>Paul Cortopassi current term ends 11/30/2016</li>
 	<li>Joseph Hernandez current term ends 11/30/2018</li>
 	<li>Dennis Miskell current term ends 11/30/2016</li>
</ul>
<h3>Staff</h3>
<ul>
 	<li>Judy Burditt - General Manager</li>
 	<li>Alex Lopez - Finance and Administrative Director</li>
 	<li>Ben Carmona - Program Director</li>
 	<li>Richard Calderon - Senior Center Coordinator</li>
 	<li>Danika Holly - Senior Nutrition Staff</li>
</ul>
<h3>After School Program Recreation Leaders</h3>
<ul>
 	<li>Maria "Rosie" Cruz</li>
 	<li>Rebecca Padgett</li>
</ul>
<h3>Maintenance Staff</h3>
<ul>
 	<li>Sal Mejia- Maintenance Worker</li>
 	<li>Jose Hernandez - Maintenance Lead</li>
</ul>', 'Board and Staff', '', 'publish', 'closed', 'closed', '', 'board-and-staff', '', '', '2017-03-28 03:57:58', '2017-03-28 03:57:58', '', 34, 'https://ncrpd-website-ernestolcortez.c9users.io/?page_id=36', 0, 'page', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-27 06:18:41', '2017-03-27 06:18:41', '', 'Board and Staff', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2017-03-27 06:18:41', '2017-03-27 06:18:41', '', 36, 'https://ncrpd-website-ernestolcortez.c9users.io/36-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-27 06:26:28', '2017-03-27 06:26:28', '<h3>Our Board Of Directors:</h3>
<ul>
 	<li>Grant Leonard- Chair  current term ends 11/30/2018</li>
 	<li>Kristen Henderson- Vice Chair current term ends 11/30/2018</li>
 	<li>Paul Cortopassi current term ends 11/30/2016</li>
 	<li>Joseph Hernandez current term ends 11/30/2018</li>
 	<li>Dennis Miskell current term ends 11/30/2016</li>
</ul>
<h3>Staff</h3>
<ul>
 	<li>Judy Burditt - General Manager</li>
 	<li>Alex Lopez - Finance and Administrative Director</li>
 	<li>Ben Carmona - Program Director</li>
 	<li>Richard Calderon - Senior Center Coordinator</li>
 	<li>Danika Holly - Senior Nutrition Staff</li>
</ul>
<h3>After School Program Recreation Leaders</h3>
<ul>
 	<li>Maria "Rosie" Cruz</li>
 	<li>Rebecca Padgett</li>
</ul>
<h3>Maintenance Staff</h3>
<ul>
 	<li>Sal Mejia- Maintenance Worker</li>
 	<li>Jose Hernandez - Maintenance Lead</li>
</ul>', 'Board and Staff', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2017-03-27 06:26:28', '2017-03-27 06:26:28', '', 36, 'https://ncrpd-website-ernestolcortez.c9users.io/36-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 03:59:08', '2017-03-28 03:59:08', '<h3>Public Records Request Policy</h3>
Public records maintained by the District shall be available for inspection during the regular business hours of the District. The General Manager, or his or her designee, shall be the official custodian of District records and shall make any nonexempt records freely available to the public in accordance with Government Code section 6250 et seq. The District may refuse to make available records that are exempt from disclosure pursuant to Government Code section 6254 or other applicable law. The District shall not disclose records that assess vulnerability to terrorist attack or other criminal acts intended to disrupt the District’s operations or the disclosure of which would compromise the workplace security of the District’s facilities, operations, or personnel.
<h3>Requests for Inspection or Copies of District Records</h3>
Members of the public who wish to inspect or obtain copies of any public record must submit their request to the office of the General Manager specifying the desired records. Requests should be specific, focused and not unreasonably interfere with the ordinary business operations of the District. The request should sufficiently describe records so that identification, location and retrieval of the records can be achieved in a timely manner by District personnel, and should include the name and address of the requestor and a telephone number where the requestor can be reached for questions of clarification that will help to identify and locate the appropriate records for retrieval. The District shall require the name and address and positive identification of any person requesting to inspect or receive copies of records relating to the location, construction, operation or maintenance of District facilities or property, along with a statement of the purpose for the inspection or receipt of copies. Positive identification may be established by a California driver’s license, California identification card or other official photographic identification. If the member of the public is unsure how to phrase a request, the District shall provide assistance as required by Government Code Section 6253.1.
<h3>The District’s Search for and Review of Responsive Records</h3>
A reasonable effort will be made to locate requested records. If the document requested cannot be located after a reasonable search, the requesting party shall so be advised. The District shall, within 10 days of receipt of the request, determine whether the request, in whole or in part, seeks dis-closable public records that are in the possession of the District and shall promptly notify the requestor of the determination by sending the requestor a letter of determination.

In unusual circumstances, the District may extend the 10 days for the determination by up to 14 additional days by written notice, setting forth the reasons for the extension and the date upon which the determination will be made. “Unusual circumstances” include instances where the records are located off site, the request is for a voluminous amount of separate records, the District needs to consult with another agency having a substantial interest in the determination, or where there is a need to compile or extract data.

If the District determines that the request seeks dis-closable records, the District will state an estimated date and time when the records will be made available in its letter of determination. The District will not delay in producing the dis-closable records but may designate an estimated date for production which is later than the 10 or 14 additional days permitted by law for the initial determination in order to review, redact as necessary and copy responsive documents. If the District determines that the records requested are not dis-closable, it will state the reasons therefore in its letter of determination and the name and title of the person responsible for the denial.
<h3>Inspection of District Records</h3>
A member of the public requesting inspection of District records shall be assisted by the General Manager or his or her designee during regular office hours at a time arranged between the District and requestor. The operational functions of the District will not be suspended to permit inspection of records during periods in which District personnel in the performance of their duties reasonably require such records. Physical inspection of the records shall be permitted within the District''s offices and under the conditions determined by the District. District employees shall not provide records deemed to be exempt from disclosure by the General Manager or his or her designee to members of the public. Upon either the completion of the inspection or the oral request of department personnel, the person conducting the inspection shall relinquish physical possession of the records. Persons inspecting District’s records shall not destroy, mutilate, deface, alter, or remove any such records from the District office. The District reserves the right to have District personnel present during the inspection of records in order to prevent the loss or destruction of records.
<h3>Advance Payment Required for Copies of District Records</h3>
After the District has completed its search for records that are responsive and dis-closable, District personnel shall notify the requestor that the records are available. The notice of availability shall include the number of pages and total cost for copying. District employees shall promptly provide copies of the records to the requestor upon the advance payment of ten cents ($.10) per page to cover the direct costs of duplication. Postage fees incurred in mailing such copies shall also be charged to the requestor.

Copies of maps, or blueprints will be supplied at the actual cost to the District for reproduction by an outside service including the hourly wage for actual staff time spent delivering and picking up the copies. Expected costs of reproduction will be collected in advance of reproduction.
<h3>Records Prepared and Filed In Accordance With the Political Reform Act</h3>
Records prepared and filed in accordance with the Political Reform Act (conflict of interest code, statements of economic interest) are public records subject to inspection and reproduction during the District’s regular business hours, commencing as soon as practicable, but no later than the second business day following the day the request for inspection was received. Copies shall be provided at a charge of ten cents ($.10) per page. Pursuant to Government Code Section 81008, a retrieval fee of five dollars ($5.00) per request shall be charged for copies of reports and statements which are five years old or more.

Posting of the Public Records Policy

A copy of this policy shall be posted in a conspicuous public place in the office of the North County Recreation and Park District and a copy thereof shall be made available free of charge to any person requesting such copy.', 'Facilities', '', 'publish', 'closed', 'closed', '', 'facilities', '', '', '2017-03-28 03:59:08', '2017-03-28 03:59:08', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?page_id=39', 0, 'page', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-27 06:34:08', '2017-03-27 06:34:08', '', 'Facilities', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2017-03-27 06:34:08', '2017-03-27 06:34:08', '', 39, 'https://ncrpd-website-ernestolcortez.c9users.io/39-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 02:12:18', '2017-03-28 02:12:18', '<h3>Welcome to the North County Recreation and Park District</h3>
NCRPD is a Local Government Agency (Special District) providing Recreation and Parks services to the North Monterey County area including the communities of Castroville, Moss Landing, Oak Hills and parts of Elkhorn and Prunedale, along with the surrounding rural community. NCRPD opperates the North County Recreation Center, Cato-Phillips Park, Crane Street Park, Japanese School Park, Rancho Moro Cojo Park and the Moro Cojo Nature Trails.
<h4>Vision</h4>
We create community through people, parks and programs.
<h4>Mission</h4>
Strengthen community image and sense of place
Support economic development
Strengthen safety and security
Promote health and wellness
Foster human development
Increase cultural unity
Protect environmental resources
Provide recreational experiences
Facilitate community problem solving
<h4>Youth</h4>
NCRPD hosts drop in recreational services for youth at the North County Rec Center Monday through Friday after school and beginning at 1pm during the summer and all school breaks. Activities include rock climbing, homework help, floor hockey, games, tournaments, crafts and cooking classes. Kids have access to the gym and any activities we offer at no charge. NCRPD is also the host site for a youth nutrition program that serves a full lunch Monday through Friday during the summer months and snack in the afternoon.
<h4>Seniors</h4>
NCRPD invites seniors all year long to enjoy cards, quilting, gym bowling, crafts, board games, bingo and a place to meet up with other seniors. Seniors also plan field trips to various local attractions like, the Monterey Bay Aquarium, Monterey County Fair, casino trips, shopping trips and more. The Castroville Senior Center also provides a HOT MEAL each weekday for a minimal donation. Guests are always welcome to join our seniors.
<h4>Adults</h4>
NCRPD offers sport leagues, recreational activities and classes for adults. The North County Recreation Center is also the local distribution site for the Monterey County Food Bank (call for schedule).

<em>Visit our Annual Events page for more information on Castroville''s Party in the Plaza: Joe Micheli Sr. Memorial Community Parade and Car Show</em>
<h4>Board Meetings and Board Agenda</h4>
The Board of Directors meet regularly on the second Wednesday of each month. Meeting time is 5:30pm. Meeting place is the North County Recreation Center-Meeting Room at 11261 Crane Street, Castroville, CA 95012. Agenda''s are prepared the Friday prior to the meeting. If you would like a topic to be placed on the agenda please call (831 633-3084) or visit the District office before that Friday.
<h3 style="text-align: center;">BOARD OF DIRECTOR’S MEETING</h3>
<img class="size-medium wp-image-44 aligncenter" src="https://ncrpd-website-ernestolcortez.c9users.io/wp-content/uploads/2017/03/dirMeetingAgenda-232x300.jpg" alt="" width="232" height="300" />

&nbsp;', 'Home', '', 'inherit', 'closed', 'closed', '', '18-autosave-v1', '', '', '2017-03-28 02:12:18', '2017-03-28 02:12:18', '', 18, 'https://ncrpd-website-ernestolcortez.c9users.io/18-autosave-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 01:32:22', '2017-03-28 01:32:22', '<h3>Welcome to the North County Recreation and Park District</h3>
NCRPD is a Local Government Agency (Special District) providing Recreation and Parks services to the North Monterey County area including the communities of Castroville, Moss Landing, Oak Hills and parts of Elkhorn and Prunedale, along with the surrounding rural community. NCRPD opperates the North County Recreation Center, Cato-Phillips Park, Crane Street Park, Japanese School Park, Rancho Moro Cojo Park and the Moro Cojo Nature Trails.
<h4>Vision</h4>
We create community through people, parks and programs.
<h4>Mission</h4>
Strengthen community image and sense of place
Support economic development
Strengthen safety and security
Promote health and wellness
Foster human development
Increase cultural unity
Protect environmental resources
Provide recreational experiences
Facilitate community problem solving
<h4>Youth</h4>
NCRPD hosts drop in recreational services for youth at the North County Rec Center Monday through Friday after school and beginning at 1pm during the summer and all school breaks. Activities include rock climbing, homework help, floor hockey, games, tournaments, crafts and cooking classes. Kids have access to the gym and any activities we offer at no charge. NCRPD is also the host site for a youth nutrition program that serves a full lunch Monday through Friday during the summer months and snack in the afternoon.
<h4>Seniors</h4>
NCRPD invites seniors all year long to enjoy cards, quilting, gym bowling, crafts, board games, bingo and a place to meet up with other seniors. Seniors also plan field trips to various local attractions like, the Monterey Bay Aquarium, Monterey County Fair, casino trips, shopping trips and more. The Castroville Senior Center also provides a HOT MEAL each weekday for a minimal donation. Guests are always welcome to join our seniors.
<h4>Adults</h4>
NCRPD offers sport leagues, recreational activities and classes for adults. The North County Recreation Center is also the local distribution site for the Monterey County Food Bank (call for schedule).

<em>Visit our Annual Events page for more information on Castroville''s Party in the Plaza: Joe Micheli Sr. Memorial Community Parade and Car Show</em>
<h4>Board Meetings and Board Agenda</h4>
The Board of Directors meet regularly on the second Wednesday of each month. Meeting time is 5:30pm. Meeting place is the North County Recreation Center-Meeting Room at 11261 Crane Street, Castroville, CA 95012. Agenda''s are prepared the Friday prior to the meeting. If you would like a topic to be placed on the agenda please call (831 633-3084) or visit the District office before that Friday.
<h3 style="text-align: center;">BOARD OF DIRECTOR’S MEETING</h3>
&nbsp;', 'Home', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-03-28 01:32:22', '2017-03-28 01:32:22', '', 18, 'https://ncrpd-website-ernestolcortez.c9users.io/18-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 01:33:53', '2017-03-28 01:33:53', '', 'dirMeetingAgenda', '', 'inherit', 'open', 'closed', '', 'dirmeetingagenda', '', '', '2017-03-28 02:06:49', '2017-03-28 02:06:49', '', 18, 'https://ncrpd-website-ernestolcortez.c9users.io/wp-content/uploads/2017/03/dirMeetingAgenda.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 02:11:00', '2017-03-28 02:11:00', '<h3>Welcome to the North County Recreation and Park District</h3>
NCRPD is a Local Government Agency (Special District) providing Recreation and Parks services to the North Monterey County area including the communities of Castroville, Moss Landing, Oak Hills and parts of Elkhorn and Prunedale, along with the surrounding rural community. NCRPD opperates the North County Recreation Center, Cato-Phillips Park, Crane Street Park, Japanese School Park, Rancho Moro Cojo Park and the Moro Cojo Nature Trails.
<h4>Vision</h4>
We create community through people, parks and programs.
<h4>Mission</h4>
Strengthen community image and sense of place
Support economic development
Strengthen safety and security
Promote health and wellness
Foster human development
Increase cultural unity
Protect environmental resources
Provide recreational experiences
Facilitate community problem solving
<h4>Youth</h4>
NCRPD hosts drop in recreational services for youth at the North County Rec Center Monday through Friday after school and beginning at 1pm during the summer and all school breaks. Activities include rock climbing, homework help, floor hockey, games, tournaments, crafts and cooking classes. Kids have access to the gym and any activities we offer at no charge. NCRPD is also the host site for a youth nutrition program that serves a full lunch Monday through Friday during the summer months and snack in the afternoon.
<h4>Seniors</h4>
NCRPD invites seniors all year long to enjoy cards, quilting, gym bowling, crafts, board games, bingo and a place to meet up with other seniors. Seniors also plan field trips to various local attractions like, the Monterey Bay Aquarium, Monterey County Fair, casino trips, shopping trips and more. The Castroville Senior Center also provides a HOT MEAL each weekday for a minimal donation. Guests are always welcome to join our seniors.
<h4>Adults</h4>
NCRPD offers sport leagues, recreational activities and classes for adults. The North County Recreation Center is also the local distribution site for the Monterey County Food Bank (call for schedule).

<em>Visit our Annual Events page for more information on Castroville''s Party in the Plaza: Joe Micheli Sr. Memorial Community Parade and Car Show</em>
<h4>Board Meetings and Board Agenda</h4>
The Board of Directors meet regularly on the second Wednesday of each month. Meeting time is 5:30pm. Meeting place is the North County Recreation Center-Meeting Room at 11261 Crane Street, Castroville, CA 95012. Agenda''s are prepared the Friday prior to the meeting. If you would like a topic to be placed on the agenda please call (831 633-3084) or visit the District office before that Friday.
<h3 style="text-align: center;">BOARD OF DIRECTOR’S MEETING</h3>
<img class="size-medium wp-image-44 aligncenter" src="https://ncrpd-website-ernestolcortez.c9users.io/wp-content/uploads/2017/03/dirMeetingAgenda-232x300.jpg" alt="" width="232" height="300" />', 'Home', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-03-28 02:11:00', '2017-03-28 02:11:00', '', 18, 'https://ncrpd-website-ernestolcortez.c9users.io/18-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 03:56:34', '2017-03-28 03:56:34', '<strong>Print and bring in to the NCRPD Office or fax to (831) 633-3160</strong>
<ul>
 	<li>Membership Application<em> (CREATE A FORMS PAGE FOR THESE FORMS)</em></li>
 	<li>Volunteer Application <em>(PLACEHOLDERS)</em></li>
 	<li>After School Programs Brochure</li>
</ul>
<strong>Program Registration Forms (Need both)</strong>
<ul>
 	<li>Program Registration Form</li>
 	<li>Waiver &amp; Medical Release</li>
</ul>
<strong>Facility Use Forms (Need permit and policies)</strong>
<ul>
 	<li>2014 Fee Schedule.pdf</li>
 	<li>Facility Use Permit</li>
 	<li>Rental Policies- Except JSP</li>
 	<li>JSP Rental Policies</li>
</ul>
<strong>Alcohol Permit and Decorating Rules (For Recreation Center Only)</strong>
<ul>
 	<li>Alcohol Use Permit</li>
 	<li>Decorating Rules</li>
</ul>', 'Programs', '', 'publish', 'closed', 'closed', '', 'programs', '', '', '2017-03-28 03:56:34', '2017-03-28 03:56:34', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?page_id=48', 0, 'page', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 03:56:34', '2017-03-28 03:56:34', '<strong>Print and bring in to the NCRPD Office or fax to (831) 633-3160</strong>
<ul>
 	<li>Membership Application<em> (CREATE A FORMS PAGE FOR THESE FORMS)</em></li>
 	<li>Volunteer Application <em>(PLACEHOLDERS)</em></li>
 	<li>After School Programs Brochure</li>
</ul>
<strong>Program Registration Forms (Need both)</strong>
<ul>
 	<li>Program Registration Form</li>
 	<li>Waiver &amp; Medical Release</li>
</ul>
<strong>Facility Use Forms (Need permit and policies)</strong>
<ul>
 	<li>2014 Fee Schedule.pdf</li>
 	<li>Facility Use Permit</li>
 	<li>Rental Policies- Except JSP</li>
 	<li>JSP Rental Policies</li>
</ul>
<strong>Alcohol Permit and Decorating Rules (For Recreation Center Only)</strong>
<ul>
 	<li>Alcohol Use Permit</li>
 	<li>Decorating Rules</li>
</ul>', 'Programs', '', 'inherit', 'closed', 'closed', '', '48-revision-v1', '', '', '2017-03-28 03:56:34', '2017-03-28 03:56:34', '', 48, 'https://ncrpd-website-ernestolcortez.c9users.io/48-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 03:59:08', '2017-03-28 03:59:08', '<h3>Public Records Request Policy</h3>
Public records maintained by the District shall be available for inspection during the regular business hours of the District. The General Manager, or his or her designee, shall be the official custodian of District records and shall make any nonexempt records freely available to the public in accordance with Government Code section 6250 et seq. The District may refuse to make available records that are exempt from disclosure pursuant to Government Code section 6254 or other applicable law. The District shall not disclose records that assess vulnerability to terrorist attack or other criminal acts intended to disrupt the District’s operations or the disclosure of which would compromise the workplace security of the District’s facilities, operations, or personnel.
<h3>Requests for Inspection or Copies of District Records</h3>
Members of the public who wish to inspect or obtain copies of any public record must submit their request to the office of the General Manager specifying the desired records. Requests should be specific, focused and not unreasonably interfere with the ordinary business operations of the District. The request should sufficiently describe records so that identification, location and retrieval of the records can be achieved in a timely manner by District personnel, and should include the name and address of the requestor and a telephone number where the requestor can be reached for questions of clarification that will help to identify and locate the appropriate records for retrieval. The District shall require the name and address and positive identification of any person requesting to inspect or receive copies of records relating to the location, construction, operation or maintenance of District facilities or property, along with a statement of the purpose for the inspection or receipt of copies. Positive identification may be established by a California driver’s license, California identification card or other official photographic identification. If the member of the public is unsure how to phrase a request, the District shall provide assistance as required by Government Code Section 6253.1.
<h3>The District’s Search for and Review of Responsive Records</h3>
A reasonable effort will be made to locate requested records. If the document requested cannot be located after a reasonable search, the requesting party shall so be advised. The District shall, within 10 days of receipt of the request, determine whether the request, in whole or in part, seeks dis-closable public records that are in the possession of the District and shall promptly notify the requestor of the determination by sending the requestor a letter of determination.

In unusual circumstances, the District may extend the 10 days for the determination by up to 14 additional days by written notice, setting forth the reasons for the extension and the date upon which the determination will be made. “Unusual circumstances” include instances where the records are located off site, the request is for a voluminous amount of separate records, the District needs to consult with another agency having a substantial interest in the determination, or where there is a need to compile or extract data.

If the District determines that the request seeks dis-closable records, the District will state an estimated date and time when the records will be made available in its letter of determination. The District will not delay in producing the dis-closable records but may designate an estimated date for production which is later than the 10 or 14 additional days permitted by law for the initial determination in order to review, redact as necessary and copy responsive documents. If the District determines that the records requested are not dis-closable, it will state the reasons therefore in its letter of determination and the name and title of the person responsible for the denial.
<h3>Inspection of District Records</h3>
A member of the public requesting inspection of District records shall be assisted by the General Manager or his or her designee during regular office hours at a time arranged between the District and requestor. The operational functions of the District will not be suspended to permit inspection of records during periods in which District personnel in the performance of their duties reasonably require such records. Physical inspection of the records shall be permitted within the District''s offices and under the conditions determined by the District. District employees shall not provide records deemed to be exempt from disclosure by the General Manager or his or her designee to members of the public. Upon either the completion of the inspection or the oral request of department personnel, the person conducting the inspection shall relinquish physical possession of the records. Persons inspecting District’s records shall not destroy, mutilate, deface, alter, or remove any such records from the District office. The District reserves the right to have District personnel present during the inspection of records in order to prevent the loss or destruction of records.
<h3>Advance Payment Required for Copies of District Records</h3>
After the District has completed its search for records that are responsive and dis-closable, District personnel shall notify the requestor that the records are available. The notice of availability shall include the number of pages and total cost for copying. District employees shall promptly provide copies of the records to the requestor upon the advance payment of ten cents ($.10) per page to cover the direct costs of duplication. Postage fees incurred in mailing such copies shall also be charged to the requestor.

Copies of maps, or blueprints will be supplied at the actual cost to the District for reproduction by an outside service including the hourly wage for actual staff time spent delivering and picking up the copies. Expected costs of reproduction will be collected in advance of reproduction.
<h3>Records Prepared and Filed In Accordance With the Political Reform Act</h3>
Records prepared and filed in accordance with the Political Reform Act (conflict of interest code, statements of economic interest) are public records subject to inspection and reproduction during the District’s regular business hours, commencing as soon as practicable, but no later than the second business day following the day the request for inspection was received. Copies shall be provided at a charge of ten cents ($.10) per page. Pursuant to Government Code Section 81008, a retrieval fee of five dollars ($5.00) per request shall be charged for copies of reports and statements which are five years old or more.

Posting of the Public Records Policy

A copy of this policy shall be posted in a conspicuous public place in the office of the North County Recreation and Park District and a copy thereof shall be made available free of charge to any person requesting such copy.', 'Facilities', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2017-03-28 03:59:08', '2017-03-28 03:59:08', '', 39, 'https://ncrpd-website-ernestolcortez.c9users.io/39-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 04:37:31', '2017-03-28 04:37:31', ' ', '', '', 'publish', 'closed', 'closed', '', '51', '', '', '2017-03-28 04:37:31', '2017-03-28 04:37:31', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?p=51', 4, 'nav_menu_item', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 04:37:32', '2017-03-28 04:37:32', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2017-03-28 04:37:32', '2017-03-28 04:37:32', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?p=52', 5, 'nav_menu_item', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 04:37:30', '2017-03-28 04:37:30', ' ', '', '', 'publish', 'closed', 'closed', '', '53', '', '', '2017-03-28 04:37:30', '2017-03-28 04:37:30', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?p=53', 2, 'nav_menu_item', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 04:37:31', '2017-03-28 04:37:31', ' ', '', '', 'publish', 'closed', 'closed', '', '54', '', '', '2017-03-28 04:37:31', '2017-03-28 04:37:31', '', 34, 'https://ncrpd-website-ernestolcortez.c9users.io/?p=54', 3, 'nav_menu_item', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 04:37:29', '2017-03-28 04:37:29', ' ', '', '', 'publish', 'closed', 'closed', '', '55', '', '', '2017-03-28 04:37:29', '2017-03-28 04:37:29', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?p=55', 1, 'nav_menu_item', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 04:37:33', '2017-03-28 04:37:33', ' ', '', '', 'publish', 'closed', 'closed', '', '56', '', '', '2017-03-28 04:37:33', '2017-03-28 04:37:33', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?p=56', 6, 'nav_menu_item', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 05:47:51', '2017-03-28 05:47:51', '<h2>Annual Events</h2>
<h3>Castroville''s Party in the Plaza:
Joe Micheli Sr. Memorial Community Parade and Car Show</h3>
Sunday, April 23rd

For more information call 633-3084.

<strong>Parade Participants Register Online:</strong> <a href="https://goo.gl/forms/JoneAY72dfTfOwfN2">https://goo.gl/forms/JoneAY72dfTfOwfN2</a>

<strong>Print Registration:</strong> <em><strong>(Placeholder)</strong></em>

<strong>Parade info and release form:</strong> <em><strong>(Placeholder)</strong></em>

<strong>Vendors Apply Online:</strong> <a href="https://goo.gl/forms/wuDOKshfhp2PnMLZ2">https://goo.gl/forms/wuDOKshfhp2PnMLZ2</a>

Print Vendor Application: <em><strong>(Placeholder)</strong></em>

<strong>Monterey County Temporary Food Vendor Application for vendors without a health permit (submit to Monterey County):</strong> <em><strong>(Placeholder)</strong></em>

<strong>Monterey County Temporary Food Vendor Application for vendors with a health permit (submit to Monterey County):</strong> <em><strong>(Placeholder)</strong></em>

<strong>California Sellers Permit Cert:</strong> <em><strong>(Placeholder)</strong></em>
<h2>Other Upcoming Events:</h2>
Halloween Fun Nite and Haunted House-October 31st

Snow Play Day- sponsored by Castroville Midnighters, North County Recreation and local merchants. Will be held on December 16, 2017. Donations for Snow are currently being accepted.
Snow Play Day sponsor committment.docx

Jr. Warriors Basketball League- Sign-ups begin in the Fall of 2017. See Programs section.

Youth Baseball Registration ends 3/31/2017. See Programs section.

Jr. Giants Baseball- Sign-ups begin in May. See Programs section.

Summer Day Camp- During NMCUSD Summer Break

Summer Youth Lunch Program- During NMCUSD Summer Break

Castroville Artichoke Festival- Third weekend of June 3rd &amp; 4th, 2017 at Monterey County Fairgrounds. KICK OFF Parade TBA.', 'Events', '', 'publish', 'closed', 'closed', '', 'events', '', '', '2017-03-28 05:47:51', '2017-03-28 05:47:51', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?page_id=57', 0, 'page', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 05:47:51', '2017-03-28 05:47:51', '<h2>Annual Events</h2>
<h3>Castroville''s Party in the Plaza:
Joe Micheli Sr. Memorial Community Parade and Car Show</h3>
Sunday, April 23rd

For more information call 633-3084.

<strong>Parade Participants Register Online:</strong> <a href="https://goo.gl/forms/JoneAY72dfTfOwfN2">https://goo.gl/forms/JoneAY72dfTfOwfN2</a>

<strong>Print Registration:</strong> <em><strong>(Placeholder)</strong></em>

<strong>Parade info and release form:</strong> <em><strong>(Placeholder)</strong></em>

<strong>Vendors Apply Online:</strong> <a href="https://goo.gl/forms/wuDOKshfhp2PnMLZ2">https://goo.gl/forms/wuDOKshfhp2PnMLZ2</a>

Print Vendor Application: <em><strong>(Placeholder)</strong></em>

<strong>Monterey County Temporary Food Vendor Application for vendors without a health permit (submit to Monterey County):</strong> <em><strong>(Placeholder)</strong></em>

<strong>Monterey County Temporary Food Vendor Application for vendors with a health permit (submit to Monterey County):</strong> <em><strong>(Placeholder)</strong></em>

<strong>California Sellers Permit Cert:</strong> <em><strong>(Placeholder)</strong></em>
<h2>Other Upcoming Events:</h2>
Halloween Fun Nite and Haunted House-October 31st

Snow Play Day- sponsored by Castroville Midnighters, North County Recreation and local merchants. Will be held on December 16, 2017. Donations for Snow are currently being accepted.
Snow Play Day sponsor committment.docx

Jr. Warriors Basketball League- Sign-ups begin in the Fall of 2017. See Programs section.

Youth Baseball Registration ends 3/31/2017. See Programs section.

Jr. Giants Baseball- Sign-ups begin in May. See Programs section.

Summer Day Camp- During NMCUSD Summer Break

Summer Youth Lunch Program- During NMCUSD Summer Break

Castroville Artichoke Festival- Third weekend of June 3rd &amp; 4th, 2017 at Monterey County Fairgrounds. KICK OFF Parade TBA.', 'Events', '', 'inherit', 'closed', 'closed', '', '57-revision-v1', '', '', '2017-03-28 05:47:51', '2017-03-28 05:47:51', '', 57, 'https://ncrpd-website-ernestolcortez.c9users.io/57-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 06:05:06', '2017-03-28 06:05:06', '<h2>Facility Rentals</h2>
We have three facilities that are available for rent.
<ul>
 	<li>North County Recreation Center</li>
 	<li>North County Sports Complex (formerly known as Japanese School Park)</li>
 	<li>Rancho Moro Cojo Park</li>
 	<li>Japanese School House</li>
</ul>
For information on renting any of our facilities contact Alex or Rosie at (831) 633-3084
<h3>Current Rates- North County Recreation Center</h3>
<h3>Standard Rental $2471 In-district/$2561 Out of District (up to 300 people) rates subject to change</h3>
Standard Rental $2910 In-district/$3000 Out of District (over 300 people) rates subject to change
<h3>North County Recreation and Park District</h3>
<strong>2016/2017 Fee Schedule (approved 8/10/16 effective 9/01/16)</strong>

<strong>FACILITY RENTAL DEPOSIT (NON REFUNDABLE) CLEANING AND DAMAGE DEPOSIT</strong>

<strong>(REFUNDABLE)</strong>

$300 Deposit for single use rentals above $750 Community Center $500

$150 Deposit for single use rentals of $350 to $750 Ball Park $200

$ 75 Deposit for single use rentals of

$150 to $349 Japanese School House $150

$ 30 Deposit for single use rentals of $75 to $149 Key Deposit $75

$ 10 Deposit for single use rentals of $74 or less
<h3>Rates</h3>
<strong>Facility Room In District/ Out of District</strong>

Recreation Center Youth Events w/alcohol 300 people upto 5 1/2 hrs $2,736 Full Day/$ 2,828 Full Day

Recreation Center Youth Events w/alcohol 400 people 5 1/2 hrs $3,188 Full Day/$ 3,281 Full Day

Recreation Center Youth Events w/alcohol served over 5 1/2 hrs add $160 per event/$ 160 per event

Recreation Center Entire upto 300 people $2,545 Full Day/$ 2,638 Full Day

Recreation Center Entire upto 400 people $2,997 Full Day/$ 3,090 Full Day

Recreation Center Extra Set up/decorating hours $ 15/hr upon availability/ $21/hr upon availability

Recreation Center Entire w/o security or insurance $161 hourly/$173 hourly

Recreation Center Entire w/security and insurance $280 hourly/$297 hourly

Recreation Center Meeting Room/Bar Area $66hourly/$71 hourly

Recreation Center Kitchen $56 hourly/$61 hourly

Recreation Center BBQ Pits $30 hourly/$36 hourly

Recreation Center Gym only (recreation) $78 hourly/$83 hourly

Recreation Center Holiday extra charge $320 Full Day/$319 Full Day

Recreation Center Staff Clean Up not in hourly rate $228 event/$227 event
<h3>Winter Rates December 10th - February 28th</h3>
Recreation Center Youth Events w/alcohol 300 people $2,324 Full Day/$2,501 Full Day

Recreation Center Youth Events w/alcohol 400 people $2,776 Full Day/$2,967 Full Day

Recreation Center Youth Events w/alcohol served over 5 1/2 hrs add $160 per event/ $160 per event

Recreation Center Entire upto 300 people $2,133 Full Day/$ 2,305Full Day

Recreation Center Entire upto 400 people $2,585 Full Day/$ 2,771 Full Day

Recreation Center Extra Set up/decorating hours $15/hr upon availability/$21/hr upon availability

Recreation Center Entire w/o security or insurance $121 hourly/$134 hourly

Recreation Center Entire w/security or insurance $228 hourly/$247 hourly

North County Sports Complex Ball Park Full $52 hourly/$59 hourly

North County Sports Complex Ball Park w/bathrooms $28hourly/$32 hourly

North County Sports Complex Field only $21hourly/$22 hourly

North County Sports Complex Field Prep by arrangement $32 prep/$32 prep

North County Sports Complex Tournament (outfield fencing NOT included) $1,442 Fri-Sun $1,617 Fri-Sun

Japanese School House Entire ( must add insurance $105 per day/event) $66 hourly/$71 hourly

Rancho Moro Cojo Park Ball Park w/bathrooms $27 hourly/$31 hourly

Rancho Moro Cojo Park Field only $43 hourly/$47 hourly

Rancho Moro Cojo Park Field Prep by arrangement $31 prep/$31 prep

Rancho Moro Cojo Park Picnic area w/bathrooms $52 day/$62 day

Rancho Moro Cojo Park Tournament $1,442Fri-Sun/ $1,617 Fri-Sun

Rancho Moro Cojo Park Key deposit Residents only $55$deposit

Non Profit and Youth Group rate 50% of hourly rate 50% of hourly rate

Memorial Services 50% of hourly rate 50% of hourly rate

Field Use Discount for weekly rental - must pay 1 month in advance $5 discount off hourly rate

Decorating for Hourly Rentals Rate for rentals of 4 or more hours 15$ hourly 15$ hourly

In District = Residents living within the NCRPD boundaries (Castroville, Oak Hills, Moss Landing, Elkhorn and parts of Prunedale).

RC - Entire = use of full facility; outside, gym, kitchen, bar area, bathrooms, tables and chairs. It also includes security guards, liability

Ball Park Full = Field, bathrooms and snack bar use.

NCSC Tournament = full use of field, bathrooms and snack bar on Fri from 4 to dusk, Saturday and Sunday 8 am to dusk.

Outfield fencing not included in Tournament rate, please ask staff for pricing if you would like us to set fences.

RMC Tournament = full use of field, bathrooms and picnic area on Fri from 4 to dusk, Saturday and Sunday 8 am to dusk.

Full Day = 4 hours for set up between 7:30am - 2pm and 8 hours for event. Midnight curfew.

Center will be locked at 12pm.

Equipment - Tables and chairs to seat approx. 300 people. 27 - 12ft x 30" tables (free with facility rental)

Additional tables are available for an additional fee, please ask staff for information.

Hourly Rentals must include time for set up, event and clean up. Unless NCRPD clean up is purchased. Then just set up and event time.

Dates will not be held without a Deposit!!

Final payment must be received 30 days prior to event. Failure to do so may result in cancellation of event and fees paid kept by

<em><strong>(Placeholder)</strong></em>', 'Facility Rental', '', 'publish', 'closed', 'closed', '', 'facility-rental', '', '', '2017-03-28 06:05:06', '2017-03-28 06:05:06', '', 39, 'https://ncrpd-website-ernestolcortez.c9users.io/?page_id=59', 0, 'page', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 06:05:06', '2017-03-28 06:05:06', '<h2>Facility Rentals</h2>
We have three facilities that are available for rent.
<ul>
 	<li>North County Recreation Center</li>
 	<li>North County Sports Complex (formerly known as Japanese School Park)</li>
 	<li>Rancho Moro Cojo Park</li>
 	<li>Japanese School House</li>
</ul>
For information on renting any of our facilities contact Alex or Rosie at (831) 633-3084
<h3>Current Rates- North County Recreation Center</h3>
<h3>Standard Rental $2471 In-district/$2561 Out of District (up to 300 people) rates subject to change</h3>
Standard Rental $2910 In-district/$3000 Out of District (over 300 people) rates subject to change
<h3>North County Recreation and Park District</h3>
<strong>2016/2017 Fee Schedule (approved 8/10/16 effective 9/01/16)</strong>

<strong>FACILITY RENTAL DEPOSIT (NON REFUNDABLE) CLEANING AND DAMAGE DEPOSIT</strong>

<strong>(REFUNDABLE)</strong>

$300 Deposit for single use rentals above $750 Community Center $500

$150 Deposit for single use rentals of $350 to $750 Ball Park $200

$ 75 Deposit for single use rentals of

$150 to $349 Japanese School House $150

$ 30 Deposit for single use rentals of $75 to $149 Key Deposit $75

$ 10 Deposit for single use rentals of $74 or less
<h3>Rates</h3>
<strong>Facility Room In District/ Out of District</strong>

Recreation Center Youth Events w/alcohol 300 people upto 5 1/2 hrs $2,736 Full Day/$ 2,828 Full Day

Recreation Center Youth Events w/alcohol 400 people 5 1/2 hrs $3,188 Full Day/$ 3,281 Full Day

Recreation Center Youth Events w/alcohol served over 5 1/2 hrs add $160 per event/$ 160 per event

Recreation Center Entire upto 300 people $2,545 Full Day/$ 2,638 Full Day

Recreation Center Entire upto 400 people $2,997 Full Day/$ 3,090 Full Day

Recreation Center Extra Set up/decorating hours $ 15/hr upon availability/ $21/hr upon availability

Recreation Center Entire w/o security or insurance $161 hourly/$173 hourly

Recreation Center Entire w/security and insurance $280 hourly/$297 hourly

Recreation Center Meeting Room/Bar Area $66hourly/$71 hourly

Recreation Center Kitchen $56 hourly/$61 hourly

Recreation Center BBQ Pits $30 hourly/$36 hourly

Recreation Center Gym only (recreation) $78 hourly/$83 hourly

Recreation Center Holiday extra charge $320 Full Day/$319 Full Day

Recreation Center Staff Clean Up not in hourly rate $228 event/$227 event
<h3>Winter Rates December 10th - February 28th</h3>
Recreation Center Youth Events w/alcohol 300 people $2,324 Full Day/$2,501 Full Day

Recreation Center Youth Events w/alcohol 400 people $2,776 Full Day/$2,967 Full Day

Recreation Center Youth Events w/alcohol served over 5 1/2 hrs add $160 per event/ $160 per event

Recreation Center Entire upto 300 people $2,133 Full Day/$ 2,305Full Day

Recreation Center Entire upto 400 people $2,585 Full Day/$ 2,771 Full Day

Recreation Center Extra Set up/decorating hours $15/hr upon availability/$21/hr upon availability

Recreation Center Entire w/o security or insurance $121 hourly/$134 hourly

Recreation Center Entire w/security or insurance $228 hourly/$247 hourly

North County Sports Complex Ball Park Full $52 hourly/$59 hourly

North County Sports Complex Ball Park w/bathrooms $28hourly/$32 hourly

North County Sports Complex Field only $21hourly/$22 hourly

North County Sports Complex Field Prep by arrangement $32 prep/$32 prep

North County Sports Complex Tournament (outfield fencing NOT included) $1,442 Fri-Sun $1,617 Fri-Sun

Japanese School House Entire ( must add insurance $105 per day/event) $66 hourly/$71 hourly

Rancho Moro Cojo Park Ball Park w/bathrooms $27 hourly/$31 hourly

Rancho Moro Cojo Park Field only $43 hourly/$47 hourly

Rancho Moro Cojo Park Field Prep by arrangement $31 prep/$31 prep

Rancho Moro Cojo Park Picnic area w/bathrooms $52 day/$62 day

Rancho Moro Cojo Park Tournament $1,442Fri-Sun/ $1,617 Fri-Sun

Rancho Moro Cojo Park Key deposit Residents only $55$deposit

Non Profit and Youth Group rate 50% of hourly rate 50% of hourly rate

Memorial Services 50% of hourly rate 50% of hourly rate

Field Use Discount for weekly rental - must pay 1 month in advance $5 discount off hourly rate

Decorating for Hourly Rentals Rate for rentals of 4 or more hours 15$ hourly 15$ hourly

In District = Residents living within the NCRPD boundaries (Castroville, Oak Hills, Moss Landing, Elkhorn and parts of Prunedale).

RC - Entire = use of full facility; outside, gym, kitchen, bar area, bathrooms, tables and chairs. It also includes security guards, liability

Ball Park Full = Field, bathrooms and snack bar use.

NCSC Tournament = full use of field, bathrooms and snack bar on Fri from 4 to dusk, Saturday and Sunday 8 am to dusk.

Outfield fencing not included in Tournament rate, please ask staff for pricing if you would like us to set fences.

RMC Tournament = full use of field, bathrooms and picnic area on Fri from 4 to dusk, Saturday and Sunday 8 am to dusk.

Full Day = 4 hours for set up between 7:30am - 2pm and 8 hours for event. Midnight curfew.

Center will be locked at 12pm.

Equipment - Tables and chairs to seat approx. 300 people. 27 - 12ft x 30" tables (free with facility rental)

Additional tables are available for an additional fee, please ask staff for information.

Hourly Rentals must include time for set up, event and clean up. Unless NCRPD clean up is purchased. Then just set up and event time.

Dates will not be held without a Deposit!!

Final payment must be received 30 days prior to event. Failure to do so may result in cancellation of event and fees paid kept by

<em><strong>(Placeholder)</strong></em>', 'Facility Rental', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2017-03-28 06:05:06', '2017-03-28 06:05:06', '', 59, 'https://ncrpd-website-ernestolcortez.c9users.io/59-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 08:39:37', '2017-03-28 08:39:37', '<h2>FUNiversity</h2>
<h3>What is FUNiversity?</h3>
FUNiversity is a program that allows your child to receive more supervision and activities after school, all while learning and having fun at the Rec Center.
<h3>What does my child do while in FUNiversity?</h3>
<ul>
 	<li>Your child will be picked up from school or met as the get off the bus.</li>
 	<li>We start off everyday with helping your child with their homework.</li>
 	<li>Participants must complete their homework before participating in any other activities.</li>
 	<li>Participants will be involved with activities to keep them moving and to stimulate their creative side.</li>
 	<li>We provide a snack for your child each day.</li>
 	<li>How safe is my child?</li>
</ul>
Your child is under our trained staff''s supervision from the time we pick them up until you do.
<ul>
 	<li>You as the parent must sign out your child each day. We will not release your child to anyone that you do not authorize.</li>
 	<li>Our staff are fully trained and certified in first aid and CPR.</li>
</ul>
<h3>How much does FUNiversity Cost?</h3>
<ul>
 	<li>If you pay in advance the cost to you is only $30 a week or $7 per day.</li>
 	<li>If you want to pay as you go it is $8 per day.</li>
 	<li>If you paid a babysitter your cost would average around $10 to $15 per hour or about $150 to $300 per week.</li>
</ul>', 'FUNiversity', '', 'publish', 'closed', 'closed', '', 'funiversity', '', '', '2017-03-28 08:51:09', '2017-03-28 08:51:09', '', 57, 'https://ncrpd-website-ernestolcortez.c9users.io/?page_id=61', 0, 'page', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 08:34:56', '2017-03-28 08:34:56', '<h3>Jobs with NCRPD</h3>
We currently have the following open positions:
<ul>
 	<li>P/T Administrative Assistant (15 hours week @ $12-$14/hour)</li>
 	<li>Recreation Leaders</li>
</ul>
<em><strong>(Placeholder for documentation)</strong></em>', 'Jobs', '', 'publish', 'closed', 'closed', '', 'jobs', '', '', '2017-03-28 08:34:56', '2017-03-28 08:34:56', '', 0, 'https://ncrpd-algorithmike.c9users.io/?page_id=62', 0, 'page', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 08:34:56', '2017-03-28 08:34:56', '<h3>Jobs with NCRPD</h3>
We currently have the following open positions:
<ul>
 	<li>P/T Administrative Assistant (15 hours week @ $12-$14/hour)</li>
 	<li>Recreation Leaders</li>
</ul>
<em><strong>(Placeholder for documentation)</strong></em>', 'Jobs', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2017-03-28 08:34:56', '2017-03-28 08:34:56', '', 62, 'https://ncrpd-algorithmike.c9users.io/62-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 08:39:37', '2017-03-28 08:39:37', '', 'FUNiversity', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2017-03-28 08:39:37', '2017-03-28 08:39:37', '', 61, 'https://ncrpd-algorithmike.c9users.io/61-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 08:49:29', '2017-03-28 08:49:29', '<h2>FUNiversity</h2>
<h3>What is FUNiversity?</h3>
FUNiversity is a program that allows your child to receive more supervision and activities after school, all while learning and having fun at the Rec Center.
<h3>What does my child do while in FUNiversity?</h3>
<ul>
 	<li>Your child will be picked up from school or met as the get off the bus.</li>
 	<li>We start off everyday with helping your child with their homework.</li>
 	<li>Participants must complete their homework before participating in any other activities.</li>
 	<li>Participants will be involved with activities to keep them moving and to stimulate their creative side.</li>
 	<li>We provide a snack for your child each day.</li>
 	<li>How safe is my child?</li>
</ul>
Your child is under our trained staff''s supervision from the time we pick them up until you do.

You as the parent must sign out your child each day. We will not release your child to anyone that you do not authorize.

Our staff are fully trained and certified in first aid and CPR.

How much does FUNiversity Cost?

If you pay in advance the cost to you is only $30 a week or $7 per day.

If you want to pay as you go it is $8 per day.

If you paid a babysitter your cost would average around $10 to $15 per hour or about $150 to $300 per week.', 'FUNiversity', '', 'inherit', 'closed', 'closed', '', '61-autosave-v1', '', '', '2017-03-28 08:49:29', '2017-03-28 08:49:29', '', 61, 'https://ncrpd-algorithmike.c9users.io/61-autosave-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 08:51:09', '2017-03-28 08:51:09', '<h2>FUNiversity</h2>
<h3>What is FUNiversity?</h3>
FUNiversity is a program that allows your child to receive more supervision and activities after school, all while learning and having fun at the Rec Center.
<h3>What does my child do while in FUNiversity?</h3>
<ul>
 	<li>Your child will be picked up from school or met as the get off the bus.</li>
 	<li>We start off everyday with helping your child with their homework.</li>
 	<li>Participants must complete their homework before participating in any other activities.</li>
 	<li>Participants will be involved with activities to keep them moving and to stimulate their creative side.</li>
 	<li>We provide a snack for your child each day.</li>
 	<li>How safe is my child?</li>
</ul>
Your child is under our trained staff''s supervision from the time we pick them up until you do.
<ul>
 	<li>You as the parent must sign out your child each day. We will not release your child to anyone that you do not authorize.</li>
 	<li>Our staff are fully trained and certified in first aid and CPR.</li>
</ul>
<h3>How much does FUNiversity Cost?</h3>
<ul>
 	<li>If you pay in advance the cost to you is only $30 a week or $7 per day.</li>
 	<li>If you want to pay as you go it is $8 per day.</li>
 	<li>If you paid a babysitter your cost would average around $10 to $15 per hour or about $150 to $300 per week.</li>
</ul>', 'FUNiversity', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2017-03-28 08:51:09', '2017-03-28 08:51:09', '', 61, 'https://ncrpd-algorithmike.c9users.io/61-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 08:59:24', '2017-03-28 08:59:24', '', '2013-08-20_09-56-10_267', '', 'inherit', 'open', 'closed', '', '2013-08-20_09-56-10_267', '', '', '2017-03-28 08:59:24', '2017-03-28 08:59:24', '', 0, '/wp-content/uploads/2017/03/2013-08-20_09-56-10_267.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 09:01:50', '2017-03-28 09:01:50', '', '2013-08-20_10-09-23_278', '', 'inherit', 'open', 'closed', '', '2013-08-20_10-09-23_278', '', '', '2017-03-28 09:01:50', '2017-03-28 09:01:50', '', 0, '/wp-content/uploads/2017/03/2013-08-20_10-09-23_278.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 09:01:59', '2017-03-28 09:01:59', '', '2013-08-20_10-13-50_732', '', 'inherit', 'open', 'closed', '', '2013-08-20_10-13-50_732', '', '', '2017-03-28 09:01:59', '2017-03-28 09:01:59', '', 0, '/wp-content/uploads/2017/03/2013-08-20_10-13-50_732.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-03-28 09:02:07', '2017-03-28 09:02:07', '', '2013-08-20_10-21-59_153', '', 'inherit', 'open', 'closed', '', '2013-08-20_10-21-59_153', '', '', '2017-03-28 09:02:07', '2017-03-28 09:02:07', '', 0, '/wp-content/uploads/2017/03/2013-08-20_10-21-59_153.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (2, '2017-03-28 16:38:35', '2017-03-28 16:38:35', '<img src="http://www.ncrpd.org/mediac/400_0/media/91167c5b636e833fffff82e6ffffe907.jpg" />', 'BOARD OF DIRECTOR’S MEETING', '', 'publish', 'open', 'open', '', 'board-of-directors-meeting', '', '', '2017-03-28 16:38:35', '2017-03-28 16:38:35', '', 0, 'https://ncrpd-website-ernestolcortez.c9users.io/?p=73', 0, 'post', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (2, '2017-03-28 16:38:08', '2017-03-28 16:38:08', '<img src="http://www.ncrpd.org/mediac/400_0/media/91167c5b636e833fffff82e6ffffe907.jpg" />', 'BOARD OF DIRECTOR’S MEETING', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2017-03-28 16:38:08', '2017-03-28 16:38:08', '', 73, 'https://ncrpd-website-ernestolcortez.c9users.io/73-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (2, '2017-03-28 19:19:48', '2017-03-28 19:19:48', '<img src="http://www.ncrpd.org/mediac/400_0/media/91167c5b636e833fffff82e6ffffe907.jpg" />

&nbsp;

www.google.com

&nbsp;

Test message ohglajfg;lkasjfg;lksfjg', 'BOARD OF DIRECTOR’S MEETING', '', 'inherit', 'closed', 'closed', '', '73-autosave-v1', '', '', '2017-03-28 19:19:48', '2017-03-28 19:19:48', '', 73, 'https://ncrpd-website-ernestolcortez.c9users.io/73-autosave-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (2, '2017-05-06 17:54:42', null, '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-05-06 17:54:42', null, '', 0, '/?p=76', 0, 'post', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-05-06 17:55:07', null, '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-05-06 17:55:07', null, '', 0, '/?p=77', 0, 'post', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-05-07 02:19:07', '2017-05-07 02:19:07', '{
    "travelify_theme_options[social_facebook]": {
        "value": "https://www.facebook.com/ncrpd/",
        "type": "option",
        "user_id": 1
    }
}', '', '', 'trash', 'closed', 'closed', '', 'a8da39bb-56bb-4bdb-8178-b20c5fc2dd0b', '', '', '2017-05-07 02:19:07', '2017-05-07 02:19:07', '', 0, '/a8da39bb-56bb-4bdb-8178-b20c5fc2dd0b/', 0, 'customize_changeset', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-05-07 02:21:36', '2017-05-07 02:21:36', '{
    "show_on_front": {
        "value": "page",
        "type": "option",
        "user_id": 1
    }
}', '', '', 'trash', 'closed', 'closed', '', '6e76d627-220a-4b53-a79e-5abcb9eb8c75', '', '', '2017-05-07 02:21:36', '2017-05-07 02:21:36', '', 0, '/6e76d627-220a-4b53-a79e-5abcb9eb8c75/', 0, 'customize_changeset', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-05-07 02:25:37', '2017-05-07 02:25:37', '[gallery ids="22,23"]
<h3>Welcome to the North County Recreation and Park District</h3>
NCRPD is a Local Government Agency (Special District) providing Recreation and Parks services to the North Monterey County area including the communities of Castroville, Moss Landing, Oak Hills and parts of Elkhorn and Prunedale, along with the surrounding rural community. NCRPD opperates the North County Recreation Center, Cato-Phillips Park, Crane Street Park, Japanese School Park, Rancho Moro Cojo Park and the Moro Cojo Nature Trails.
<h4>Vision</h4>
We create community through people, parks and programs.
<h4>Mission</h4>
Strengthen community image and sense of place
Support economic development
Strengthen safety and security
Promote health and wellness
Foster human development
Increase cultural unity
Protect environmental resources
Provide recreational experiences
Facilitate community problem solving
<h4>Youth</h4>
NCRPD hosts drop in recreational services for youth at the North County Rec Center Monday through Friday after school and beginning at 1pm during the summer and all school breaks. Activities include rock climbing, homework help, floor hockey, games, tournaments, crafts and cooking classes. Kids have access to the gym and any activities we offer at no charge. NCRPD is also the host site for a youth nutrition program that serves a full lunch Monday through Friday during the summer months and snack in the afternoon.
<h4>Seniors</h4>
NCRPD invites seniors all year long to enjoy cards, quilting, gym bowling, crafts, board games, bingo and a place to meet up with other seniors. Seniors also plan field trips to various local attractions like, the Monterey Bay Aquarium, Monterey County Fair, casino trips, shopping trips and more. The Castroville Senior Center also provides a HOT MEAL each weekday for a minimal donation. Guests are always welcome to join our seniors.
<h4>Adults</h4>
NCRPD offers sport leagues, recreational activities and classes for adults. The North County Recreation Center is also the local distribution site for the Monterey County Food Bank (call for schedule).

<em>Visit our Annual Events page for more information on Castroville''s Party in the Plaza: Joe Micheli Sr. Memorial Community Parade and Car Show</em>
<h4>Board Meetings and Board Agenda</h4>
The Board of Directors meet regularly on the second Wednesday of each month. Meeting time is 5:30pm. Meeting place is the North County Recreation Center-Meeting Room at 11261 Crane Street, Castroville, CA 95012. Agenda''s are prepared the Friday prior to the meeting. If you would like a topic to be placed on the agenda please call (831 633-3084) or visit the District office before that Friday.
<h3 style="text-align: center;">BOARD OF DIRECTOR’S MEETING</h3>
<img class="size-medium wp-image-44 aligncenter" src="https://ncrpd-website-ernestolcortez.c9users.io/wp-content/uploads/2017/03/dirMeetingAgenda-232x300.jpg" alt="" width="232" height="300" />', 'Home', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-05-07 02:25:37', '2017-05-07 02:25:37', '', 18, '/18-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-05-07 02:40:54', '2017-05-07 02:40:54', '<h3>Welcome to the North County Recreation and Park District</h3>
NCRPD is a Local Government Agency (Special District) providing Recreation and Parks services to the North Monterey County area including the communities of Castroville, Moss Landing, Oak Hills and parts of Elkhorn and Prunedale, along with the surrounding rural community. NCRPD opperates the North County Recreation Center, Cato-Phillips Park, Crane Street Park, Japanese School Park, Rancho Moro Cojo Park and the Moro Cojo Nature Trails.
<h4>Vision</h4>
We create community through people, parks and programs.
<h4>Mission</h4>
Strengthen community image and sense of place
Support economic development
Strengthen safety and security
Promote health and wellness
Foster human development
Increase cultural unity
Protect environmental resources
Provide recreational experiences
Facilitate community problem solving
<h4>Youth</h4>
NCRPD hosts drop in recreational services for youth at the North County Rec Center Monday through Friday after school and beginning at 1pm during the summer and all school breaks. Activities include rock climbing, homework help, floor hockey, games, tournaments, crafts and cooking classes. Kids have access to the gym and any activities we offer at no charge. NCRPD is also the host site for a youth nutrition program that serves a full lunch Monday through Friday during the summer months and snack in the afternoon.
<h4>Seniors</h4>
NCRPD invites seniors all year long to enjoy cards, quilting, gym bowling, crafts, board games, bingo and a place to meet up with other seniors. Seniors also plan field trips to various local attractions like, the Monterey Bay Aquarium, Monterey County Fair, casino trips, shopping trips and more. The Castroville Senior Center also provides a HOT MEAL each weekday for a minimal donation. Guests are always welcome to join our seniors.
<h4>Adults</h4>
NCRPD offers sport leagues, recreational activities and classes for adults. The North County Recreation Center is also the local distribution site for the Monterey County Food Bank (call for schedule).

<em>Visit our Annual Events page for more information on Castroville''s Party in the Plaza: Joe Micheli Sr. Memorial Community Parade and Car Show</em>
<h4>Board Meetings and Board Agenda</h4>
The Board of Directors meet regularly on the second Wednesday of each month. Meeting time is 5:30pm. Meeting place is the North County Recreation Center-Meeting Room at 11261 Crane Street, Castroville, CA 95012. Agenda''s are prepared the Friday prior to the meeting. If you would like a topic to be placed on the agenda please call (831 633-3084) or visit the District office before that Friday.
<h3 style="text-align: center;">BOARD OF DIRECTOR’S MEETING</h3>
<img class="size-medium wp-image-44 aligncenter" src="https://ncrpd-website-ernestolcortez.c9users.io/wp-content/uploads/2017/03/dirMeetingAgenda-232x300.jpg" alt="" width="232" height="300" />', 'Home', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-05-07 02:40:54', '2017-05-07 02:40:54', '', 18, '/18-revision-v1/', 0, 'revision', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-05-07 02:42:52', '2017-05-07 02:42:52', '', 'NCountyRegParks_FullColor', '', 'inherit', 'open', 'closed', '', 'ncountyregparks_fullcolor', '', '', '2017-05-07 02:42:52', '2017-05-07 02:42:52', '', 0, '/wp-content/uploads/2017/05/NCountyRegParks_FullColor.jpg', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-05-07 02:43:10', '2017-05-07 02:43:10', '{
    "travelify_theme_options[header_logo]": {
        "value": "/wp-content/uploads/2017/05/NCountyRegParks_FullColor.jpg",
        "type": "option",
        "user_id": 1
    },
    "travelify_theme_options[header_show]": {
        "value": "header-logo",
        "type": "option",
        "user_id": 1
    }
}', '', '', 'trash', 'closed', 'closed', '', '722e18f3-2f21-46c1-8d3a-db49879e2d13', '', '', '2017-05-07 02:43:10', '2017-05-07 02:43:10', '', 0, '/722e18f3-2f21-46c1-8d3a-db49879e2d13/', 0, 'customize_changeset', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-05-07 02:43:27', '2017-05-07 02:43:27', '{
    "travelify_theme_options[header_show]": {
        "value": "header-text",
        "type": "option",
        "user_id": 1
    }
}', '', '', 'trash', 'closed', 'closed', '', '247a870d-78db-493a-8544-bc5ea8049c32', '', '', '2017-05-07 02:43:27', '2017-05-07 02:43:27', '', 0, '/247a870d-78db-493a-8544-bc5ea8049c32/', 0, 'customize_changeset', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-05-07 02:52:58', '2017-05-07 02:52:58', '{
    "show_on_front": {
        "value": "page",
        "type": "option",
        "user_id": 1
    }
}', '', '', 'trash', 'closed', 'closed', '', 'd4a0ed70-c495-4284-aa4c-c1133c50c08d', '', '', '2017-05-07 02:52:58', '2017-05-07 02:52:58', '', 0, '/d4a0ed70-c495-4284-aa4c-c1133c50c08d/', 0, 'customize_changeset', '', 0);
INSERT INTO c9.wp_posts (post_author, post_date, post_date_gmt, post_content, post_title, post_excerpt, post_status, comment_status, ping_status, post_password, post_name, to_ping, pinged, post_modified, post_modified_gmt, post_content_filtered, post_parent, guid, menu_order, post_type, post_mime_type, comment_count) VALUES (1, '2017-05-07 02:59:28', '2017-05-07 02:59:28', '{
    "travelify_theme_options[default_layout]": {
        "value": "no-sidebar",
        "type": "option",
        "user_id": 1
    }
}', '', '', 'trash', 'closed', 'closed', '', '886b0167-7e86-4936-a47a-0e005faba177', '', '', '2017-05-07 02:59:28', '2017-05-07 02:59:28', '', 0, '/886b0167-7e86-4936-a47a-0e005faba177/', 0, 'customize_changeset', '', 0);