INSERT INTO c9.wp_terms (name, slug, term_group) VALUES ('Uncategorized', 'uncategorized', 0);
INSERT INTO c9.wp_terms (name, slug, term_group) VALUES ('simple', 'simple', 0);
INSERT INTO c9.wp_terms (name, slug, term_group) VALUES ('grouped', 'grouped', 0);
INSERT INTO c9.wp_terms (name, slug, term_group) VALUES ('variable', 'variable', 0);
INSERT INTO c9.wp_terms (name, slug, term_group) VALUES ('external', 'external', 0);
INSERT INTO c9.wp_terms (name, slug, term_group) VALUES ('Navigation', 'navigation', 0);